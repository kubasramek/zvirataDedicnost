﻿using System.Collections.Generic;
using System.Windows;

namespace AnimalApp
{
    public partial class MainWindow : Window
    {
        public List<Animal> Zvirata { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Zvirata = new List<Animal>
            {
                new Pes { Jmeno = "Rex", PocetNohou = 4, UmiLetat = false, Barva = "Modrá", ZvukStekani = "Haf Haf" },
                new Kocka { Jmeno = "Maruna", PocetNohou = 4, UmiLetat = false, Barva = "Bílá", ZvukMnoukani = "Mňaaaau" },
                new Ptak { Jmeno = "Michal", PocetNohou = 2, UmiLetat = true, Barva = "Ružová", ZvukCvikani = "Vrků" },
            };
            animalsListBox.ItemsSource = Zvirata;
        }

        private void animalsListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            Animal vybraneZvire = (Animal)animalsListBox.SelectedItem;


            animalDetailsTextBox.Text = $"Jméno: {vybraneZvire.Jmeno}\n" +
                                        $"Počet nohou: {vybraneZvire.PocetNohou}\n" +
                                        $"Umí létat: {(vybraneZvire.UmiLetat ? "Ano" : "Ne")}\n" +
                                        $"Barva: {vybraneZvire.Barva}\n";
            animalDetailsTextBox.Text += $"Zvuk: {vybraneZvire.VydejZvuk()}";
        }
    }








    public class Animal
    {
        public string Jmeno { get; set; }
        public int PocetNohou { get; set; }
        public bool UmiLetat { get; set; }
        public string Barva { get; set; }

        public virtual string VydejZvuk()
        {
            return "Neumím dělat zvuky(asi)";
        }

        public string TypeName => GetType().Name;
    }

    public class Pes : Animal
    {
        public string ZvukStekani { get; set; }

        public override string VydejZvuk()
        {
            return ZvukStekani;
        }
    }

    public class Kocka : Animal
    {
        public string ZvukMnoukani { get; set; }

        public override string VydejZvuk()
        {
            return ZvukMnoukani;
        }
    }

    public class Ptak : Animal
    {
        public string ZvukCvikani { get; set; }

        public override string VydejZvuk()
        {
            return ZvukCvikani;
        }
    }
   
}